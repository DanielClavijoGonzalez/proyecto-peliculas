import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';

import {TablaComponent} from './tabla/tabla.component';
import {InformacionComponent} from './informacion/informacion.component';
import {RegistroComponent} from './registro/registro.component';
import {LoginComponent} from './login/login.component';
import {PeliculasComponent} from './peliculas/peliculas.component'
const routes: Routes = [
  {path: '', component:LoginComponent },
  {path:'informacion' , component:InformacionComponent },
  {path: 'registro' , component:RegistroComponent },
  {path: 'login' , component:LoginComponent },
  {path: 'tabla' , component:TablaComponent },
  {path: 'peliculas/:idmovie' , component:PeliculasComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
