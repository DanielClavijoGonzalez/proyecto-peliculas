import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../services.service';
import { UsuariosService } from '../usuarios.service';
import {Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  //form
  form: FormGroup;
  message;
  estadobol:boolean = false;
  constructor(public service: ServicesService,public usuario:UsuariosService,private fb: FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      nombres: ['', Validators.required],
      documento: ['', Validators.required],
      correo: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  Registrar(){
    if(this.form.valid){
      this.usuario.postform('http://localhost:5000/registro', {
        nombres: this.form.value.nombres,
        documento: this.form.value.documento,
        correo: this.form.value.correo,
        password: this.form.value.password
      }).subscribe(
        //cuando la respuesta del server llega es emitida por el observable mediante next()..
        (response: any) => {
          this.message = response["status"];
          //se imprime la respuesta del server
          if(this.message ==="Registro Exitoso"){
            this.estadobol = true;
            setTimeout(() => {
              this.router.navigate(['/tabla']);
            }, 2000);
          }
          console.log(response);

          //localStorage.setItem('mensaje',response["status"])

          //console.log(localStorage.getItem('mensaje'));

          //this.route.navigate( ['/ayuda']);
      },
      //si ocurre un error en el proceso de envío del formulario...
      (error) => {
        //se imprime el status del error
        console.log(error.status);
      })
    }
  }
}
