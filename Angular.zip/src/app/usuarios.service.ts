import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  constructor(private http: HttpClient) { }

  //LISTA DE PELICULAS
  getpeliculas(route: string) {
    let config:any = {
      responseType: "json"
    }
    const header = new HttpHeaders().set('Authorization', '57ydf544ljka559ahjkfgd1');
    config["header"] = header;
    return this.http.get(route, config);
  }
    //FORMULARIO FORM
    postform(route: string, data?:any) {
      let config:any = {
        responseType: "json"
      }
      const header = new HttpHeaders().set('Authorization', '57ydf544ljka559ahjkfgd1');
      config["header"] = header;
      //Notese que como tercer parametro se pasa la configuracion de la request
      return this.http.post(route, data, config);
    }
    /*getusuario(route: string, correo:any,password:any){
      let config:any = {
        responseType: "json"
      }
      const params = new HttpParams().set('correo', `${correo}`).set('password', `${password}`);
      config["params"] = params;
  
      const header = new HttpHeaders().set('Authorization', '57ydf544ljka559ahjkfgd1');
      config["header"] = header;
      //Notese que como segundo parametro se pasa la configuracion de la request
      return this.http.get(route, config);
    }*/
    postformd(route: string, data?:any) {
      let config:any = {
        responseType: "json"
      }
      const header = new HttpHeaders().set('Authorization', '57ydf544ljka559ahjkfgd1');
      config["header"] = header;
      //Notese que como tercer parametro se pasa la configuracion de la request
      return this.http.post(route, data, config);
    }
}
