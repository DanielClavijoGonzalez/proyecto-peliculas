import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../usuarios.service';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {

  idpelicula;
  peliculas;
  estado:boolean = false;
  estadod:boolean = true;
  constructor(public usuario:UsuariosService) { }

  ngOnInit(): void {
    
  }
  consultarpeliculas(){
    this.estadod = false;
    this.estado = true;
    this.usuario.getpeliculas("http://www.omdbapi.com/?s="+this.idpelicula+"&apikey=9b79d317").subscribe(
      data => this.peliculas=data["Search"],
      error => console.log("Ha ocurrido un error en la llamada",error)
    )
  }
}
