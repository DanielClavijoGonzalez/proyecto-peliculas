import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../usuarios.service';
import {Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  correo;
  password;
  form: FormGroup;
  message;
  ruta:string;
  estado:boolean = false;
  constructor(public usuario:UsuariosService,private fb: FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      correo: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  validar(){
    if(this.form.valid){
      this.usuario.postformd('/consultarusuario', {
        correo: this.form.value.correo,
        password: this.form.value.password
      }).subscribe(
        //cuando la respuesta del server llega es emitida por el observable mediante next()..
        (response: any) => {
          this.estado = true;

          //MENSAJE DE BACKEND
          this.message = response["datos"];

          //Navagacion
          //DATOS CORRECTOS
          if(this.message ==="Datos ingresados correctamente"){
            //SET TIME OUT
            setTimeout(() => {
              this.ruta = "http://localhost:5000/tabla";//RUTA
              this.router.navigate([this.ruta]);
            }, 2000);
          }
          //se imprime la respuesta del server
          console.log(response);

          //localStorage.setItem('mensaje',response["status"])

          //console.log(localStorage.getItem('mensaje'));

      },
      //si ocurre un error en el proceso de envío del formulario...
      (error) => {
        //se imprime el status del error
        console.log(error.status);
      })
    }
  }
}
