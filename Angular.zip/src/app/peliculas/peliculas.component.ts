import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , ParamMap } from '@angular/router';
import { UsuariosService } from '../usuarios.service';
@Component({
  selector: 'app-peliculas',
  templateUrl: './peliculas.component.html',
  styleUrls: ['./peliculas.component.css']
})
export class PeliculasComponent implements OnInit {

  idmovie:any;
  peliculaid;
  arraypeliculas:any[]; 

  constructor(private route : ActivatedRoute,public usuario:UsuariosService) { }
  Mostrarpeliculaid(){
    this.usuario.getpeliculas("http://www.omdbapi.com/?i="+this.idmovie+"&apikey=9b79d317").subscribe(
      data => this.peliculaid=data,
      error => console.log("Ha ocurrido un error en la llamada",error)
    );
    //this.arraypeliculas.push(this.peliculaid);
    
  }
  ngOnInit(): void {
    this.route.paramMap
      .subscribe((params : ParamMap) => {
      this.idmovie = params.get('idmovie');
      this.Mostrarpeliculaid();
});
  }
}
